jQuery(document).ready(function() {


	if ( jQuery.browser.msie ) {} else {
	
		function depois() {
			jQuery('.slide-2013 ul li .imagem').stop().animate({"marginTop":0,"opacity":1});
			jQuery('.slide-2013 ul li h3').stop().animate({"marginLeft":0,"opacity":1});
			jQuery('.slide-2013 ul li .botao-link').stop().animate({"marginLeft":0, "opacity":1});
			jQuery('.slide-2013 ul li .checklist').stop().animate({"marginLeft":0, "opacity":1});
			
		}
		
		function antes() {
			jQuery('.slide-2013 ul li .imagem').stop().animate({"marginTop":20+"px","opacity":0});
			jQuery('.slide-2013 ul li h3').stop().animate({"marginLeft":"-"+40+"px","opacity":0});
			jQuery('.slide-2013 ul li .botao-link').stop().animate({"marginLeft":"-"+40+"px", "opacity":0});		
			jQuery('.slide-2013 ul li .checklist').stop().animate({"marginLeft":"+"+40+"px", "opacity":0});
		}
	
	}
	
	
	//slide porfolio (todos os itens)
	jQuery('.slide-2013 ul')
	.cycle({ 
		sync:	false,
		fx:     'fade', 
		speed:  1000, 
		timeout: 10000, 
		pager:  '.guia .itens',
		prev:	'.slide-2013 ul li.azul .use-as-setas .seta.esq',
		next:	'.slide-2013 ul li.azul .use-as-setas .seta.dir',
		before:	antes,
		after:	depois
	});
	
	jQuery('.slide-2013 .guia .itens a').eq(0).addClass('azul');
	jQuery('.slide-2013 .guia .itens a').eq(1).addClass('verde');
	jQuery('.slide-2013 .guia .itens a').eq(2).addClass('laranja');
	jQuery('.slide-2013 .guia .itens a').eq(3).addClass('amarelo');
	
	var setas = jQuery('.slide-2013 ul li.azul .use-as-setas');
	var tempo = 300;
	setas.fadeOut(0);
	
	jQuery('.slide-2013 .guia .itens').hover(function(){		
		setas.fadeIn(tempo);
	},function(){
		setas.fadeOut(tempo);
	});
	
	//seta a largura quando a tela ?redimensionada
	jQuery(window).resize(function(){
		var largura = jQuery(window).width();
		jQuery('.slide-2013 ul > li').css({"width":largura}, 100);
	});

});